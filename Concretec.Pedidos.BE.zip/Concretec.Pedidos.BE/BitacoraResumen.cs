﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class BitacoraResumen
    {
        public int RN_CLIENTES
        { set; get; }

        public int RM_CLIENTES
        { set; get; }

        public string UFA_CLIENTES
        { set; get; }

        public int RN_PRODUCTOS
        { set; get; }

        public int RM_PRODUCTOS
        { set; get; }

        public string UFA_PRODUCTOS
        { set; get; }

        public int RN_PERSONAL
        { set; get; }

        public int RM_PERSONAL
        { set; get; }

        public string UFA_PERSONAL
        { set; get; }

        public int RN_OBRAS
        { set; get; }

        public int RM_OBRAS
        { set; get; }

        public string UFA_OBRAS
        { set; get; }
    }
}
