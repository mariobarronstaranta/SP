﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class CLIE_CLIB
    {
        public string CVE_CLIE { set; get; }

        public string CAMPLIB1 { set; get; }
        public string CAMPLIB2 { set; get; }
        public string CAMPLIB3 { set; get; }
        public string CAMPLIB4 { set; get; }
        public string CAMPLIB5 { set; get; }
        public string CAMPLIB6 { set; get; }
        public string CAMPLIB7 { set; get; }
        public string CAMPLIB8 { set; get; }
    }
}
