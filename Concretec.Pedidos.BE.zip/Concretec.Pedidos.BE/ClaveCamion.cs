﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class ClaveCamion
    {
        public int IDClaveCamion
        { set; get; }

        public string CveCamion
        { set; get; }

        public string Descripcion
        { set; get; }
    }
}
