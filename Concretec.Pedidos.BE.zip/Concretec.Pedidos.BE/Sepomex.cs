﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class Sepomex
    {
        public string CP_ID { get; set; }
        public string CP { get; set; }
        public string Municipio { get; set; }
        public string Estado { get; set; }
        public string CveEstado { get; set; }
        public string CveMunicipio { get; set; }
        public string CveLocalidad { get; set; }

    }
}
