﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class UnidadOperador
    {
        public int IDUnidadPersonal
        { set; get; }

        public int IDUnidad
        { set; get; }

        public int IDPersonal
        { set; get; }
    }
}
