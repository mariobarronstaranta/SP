﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class TipoCombustible
    {
        public int IDTipoCombustible
        { set; get; }

        public string Descripcion
        { set; get; }
    }
}
