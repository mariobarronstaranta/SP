﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class Perfil
    {
        public int IDPerfil
        { set; get; }

        public int IDPlanta
        { set; get; }

        public string Descripcion
        { set; get; }
    }
}
