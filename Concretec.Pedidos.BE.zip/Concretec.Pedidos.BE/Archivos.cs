﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class Archivos
    {
        public string TipoArchivo
        { set; get; }

        public string Nombre
        { set; get; }

        public string Ciudad
        { set; get; }
    }
}
