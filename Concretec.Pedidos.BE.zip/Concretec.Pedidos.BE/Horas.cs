﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
    public class Horas
    {
        public enum horas {Siete=7,Ocho = 8};

    }
}
