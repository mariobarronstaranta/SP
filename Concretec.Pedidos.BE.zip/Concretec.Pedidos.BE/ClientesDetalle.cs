﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Concretec.Pedidos.BE
{
   public class ClientesDetalle:Cliente
    {
        public string    clasific{ set; get; }
        public string    dias_cre{ set; get; }
        public string    fch_ultcom{ set; get; }
        public string    descuento{ set; get; }
        public string    vtas{ set; get; }
        public string    obser{ set; get; }
        public string    curp{ set; get; }
        public string    cve_zona{ set; get; }
        public string    telefonos{ set; get; }
        public string    ult_pagod{ set; get; }
        public string    ult_ventd{ set; get; }
        public string    camlibre1{ set; get; }
        public string    camlibre2{ set; get; }
        public string    camlibre3{ set; get; }
        public string    ultpagf{ set; get; }
        public string    retxflete{ set; get; }
        public string    camlibre4{ set; get; }
        public string    porcreten{ set; get; }
        public string    camlibre5{ set; get; }
        public string    ult_pagom{ set; get; }
        public string    ult_ventm{ set; get; }
        public string    camlibre6{ set; get; }
        public string    zona{ set; get; }
        public string    imprir{ set; get; }
        public string    mail{ set; get; }
        public string    nivelsec{ set; get; }
        public string    enviosilen{ set; get; }
        public string    emailpred { set; get; }
        public string cveciudad { set; get; }

    }
}
